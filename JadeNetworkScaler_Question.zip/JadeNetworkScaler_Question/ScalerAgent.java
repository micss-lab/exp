package JadeNetworkScaler_Question;


import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;

import java.net.URISyntaxException;


public class ScalerAgent extends Agent {

    ScalerAgentEnvironment sae = new ScalerAgentEnvironment();

    static int currentWorkLoad = 0;
    static int arrivedTurn = 0;
    static String responseTime="none";
    static String workLoad="none";
    static int arrivedWorkload;






    @Override
    protected void setup() {

        try {
            sae.init();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        // Add the behavior directly in the setup method
        addBehaviour(new TickerBehaviour(this,50) {
            @Override
            public void onTick() {
                try {

                    if ((currentWorkLoad==0)||arrivedTurn==0) {

                            sae.();
                            block(1);
                            sae.();
                            block(1);
                            this.arrangeResourceScale();

                    } else if (currentWorkLoad!=0) {

                        sae.();
                        this.arrangeResourceScale();

                    }





                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                }
            }

            public void arrangeResourceScale() {

                String rule = "";
                int factor = 0;





                System.out.println(rule);
                sae.;
                sae.;
            }


        });
    }






}